#!/bin/bash
if [[ -f $Mochila/pergamino.gpg ]]
then #descifrar

read -p "Venga, vamos a descifrar el pergamino, ahora tendrás que decirme la clave de descifrado.
Pulsa la tecla [INTRO] cuando estés preparado" abc


  gpg -o pergamino.invertido -d $Mochila/pergamino.gpg



  echo "Aquí tienes el pergamino descifrado, el problema es que el texto está invertido!!!! 
Te lo guardo en tu Mochila. 

Tendrás que buscar a Obi Wan Kenobi, ves a Valentia y busca bien por allí."

  mv pergamino.invertido $Mochila
  cat $Mochila/pergamino.invertido

else echo "No has traido ningún documento para descifrar. Comprueba que tienes el pergamino cifrado"
fi



