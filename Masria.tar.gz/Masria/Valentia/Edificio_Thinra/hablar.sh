#!/bin/bash

if [[ -f $Mochila/traje_shinra ]]

then

	if [[ -f $Mochila/autorizacion.txt ]]

	then 
		echo "El traje te sienta muy bien..."
		echo "Veo que traes la autorizacion."
		
		num=$(cat $Mochila/autorizacion.txt | wc -w)

		if [[ $num -le 82 ]]
		
		then 
			echo "La autorización no está firmada. Que raro..."
			echo "Debes Firmarla con tu nombre y volver a hablar conmigo! (pista editor texto nano) "
			read -p "Quieres Firmarla ahora? [S/N]" yes
			case $yes in
			S|s)
				
				nano $Mochila/autorizacion.txt
				exit 0 ;;
			N|n)
				exit ;;
			*)	exit ;;
			esac
		else
			echo "Parece que has firmado la autorizacion."

			echo "aquí tienes tu pasaporte, guapo"

			echo "--------------------------------
| Pasaporte para Claud Estraif |
--------------------------------" > $Mochila/pasaporte.id
			echo "--------------------------------
| Pasaporte para Claud Estraif |
--------------------------------"


		fi

	else
		echo "No has traido ninguna autorización para Pedir el pasaporte. Si vuelves sin ella"
		echo "tendré que abrirte un expediente."
		exit 0
	fi



else
	echo "No vas vestido de manera adecuada. No has lavado tu traje de shinra??"
fi
