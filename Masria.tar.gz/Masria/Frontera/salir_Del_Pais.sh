#!/bin/bash

num=$(ps | grep "[s]ephiroth" | wc -l)

if [[ $num -gt 0 ]]
then
	echo "Sephiroth: Primero deberás acabar conmigo. ¡Lucha cobarde!"
	exit
fi



if [[ -f $Mochila/espada_mitrilo ]]
then
	rm $Mochila/espada_mitrilo
	cat .carcel
	exit 0
fi



if [[ -f $Mochila/pasaporte.id ]]

then
	texto=$(cat .fin_del_juego)
	clear
	echo -e "\033[1;32m$texto\033[0;39m"
else
	echo "No has traido el PASAPORTE, acaso eres un traidor?"
fi
