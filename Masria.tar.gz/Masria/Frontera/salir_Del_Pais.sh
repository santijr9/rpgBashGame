#!/bin/bash

if [[ -f $Mochila/espada_mitrilo ]]

then
	rm $Mochila/espada_mitrilo
	cat .carcel
	exit 0
fi



if [[ -f $Mochila/pasaporte.id ]]

then
	texto=$(cat .fin_del_juego)
	clear
	echo -e "\033[1;32m$texto\033[0;39m"
else
	echo "No has traido el PASAPORTE, acaso eres un traidor?"
fi
