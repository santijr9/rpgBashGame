

if [[ -f $Mochila/cinturon_pirata ]]
then #intercambiar

  echo "Aquí tienes la autorización. El problema es que el pirata que las gestiona
  me la ha conseguido encriptada y no se puede leer ahora mismo. Tendrás
  que descifrarla primero. Busca a Fred el científico, él te ayudará en eso.

  La clave de descrifrado es: 'Maracaibo'"


  rm $Mochila/cinturon_pirata
  cp cosas_de_Guybrush/pergamino.gpg $Mochila/pergamino.gpg

#  mv ../ManiacMansion/.escenario1 ../ManiacMansion/.escenario.old
#  mv ../ManiacMansion/.escenario2 ../ManiacMansion/.escenario
rm ../ManiacMansion/.escenario
ln -s ../ManiacMansion/.escenario2 ../ManiacMansion/.escenario
mv ../ManiacMansion/.descifrar.sh ../ManiacMansion/descifrar.sh

  echo "
------------- Libro sobre cifrado clave con clave secreta ------------------
|                                                                          |
|  Para descifrar ficheros cifrados con extensión .gpg debes conocer       |
|  la clave de descifrado.                                                 |
|                                                                          |
|  gpg -d fichero_cifrado.gpg                                              |
|                                                                          |
|  y a continuación el comando te pedirá la clave de descifrado.           |
|  (Se genera un fichero descifrado en la ubicación actual,                |
|  guárdalo en tu mochila.)                                                |
----------------------------------------------------------------------------" > ../ManiacMansion/Libro_de_Cifrado

else echo "No intentes timarme, no has traido el Cinturon. No hay trato."
fi
