#! /bin/bash
read -p "EL traje Thinra vale 50 Rupias. Quieres comprarlo? [S/N]" compra

case $compra in
S|s)
    echo "De acuerdo, es tuyo."
    echo "50" > $Mochila/monedas
    touch $Mochila/traje_shinra
  ;;
N|n)
    echo "Si te lo piensas mejor, aquí estoy."
  ;;
*)
    echo "Debes introducir S ó N."
  ;;
esac
