#!/bin/bash

if [[ -f $Mochila/pergamino.invertido ]]

then
	echo "----- USANDO LA FUERZA JEDI -----"
	echo "Aquí lo tienes: (Te lo guardo en la Mochila)"
	rev $Mochila/pergamino.invertido > $Mochila/autorizacion.txt
	cat $Mochila/autorizacion.txt


else
	echo "No traes el pergamino invertido. NO VUELVAS SIN ÉL"
fi
